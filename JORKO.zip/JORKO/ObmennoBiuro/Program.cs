﻿namespace ObmennoBiuro
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vavedete valutat v koyato iskate da investirate (ETH, BTC, XRP):");
            string currency = Console.ReadLine();
            Console.WriteLine("Kolko evro shte investirate?");
            double euros = double.Parse(Console.ReadLine());

            double bonusRate = euros > 1000 ? 0.10 : 0.0;
            euros += euros * bonusRate;

            switch (currency.ToUpper())
            {
                case "XRP":
                    double xrpPrice = 0.22;
                    double xrpCoins = euros / xrpPrice;

                    if (xrpCoins >= 2500)
                    {
                        xrpCoins += xrpCoins * 0.10;
                    }
                    else if (xrpCoins > 1000)
                    {
                        xrpCoins += xrpCoins * 0.05;
                    }

                    if (xrpCoins >= 80)
                    {
                        Console.WriteLine($"Successfully purchased {xrpCoins:F3} {currency}");
                    }
                    else
                    {
                        Console.WriteLine("Insufficient funds.");
                    }
                    break;

                case "BTC":
                    double btcPrice = 6400;
                    double btcCoins = euros / btcPrice;

                    if (btcCoins > 10)
                    {
                        btcCoins += btcCoins * 0.02;
                    }

                    if (btcCoins >= 0.001)
                    {
                        Console.WriteLine($"Successfully purchased {btcCoins:F3} {currency}");
                    }
                    else
                    {
                        Console.WriteLine("Insufficient funds.");
                    }
                    break;

                case "ETH":
                    double ethPrice = 250;
                    double ethCoins = euros / ethPrice;

                    if (ethCoins >= 0.0099)
                    {
                        Console.WriteLine($"Successfully purchased {ethCoins:F3} {currency}");
                    }
                    else
                    {
                        Console.WriteLine("Insufficient funds.");
                    }
                    break;

                default:
                    Console.WriteLine($"EUR to {currency} is not supported.");
                    break;
            }
        }
    }
}