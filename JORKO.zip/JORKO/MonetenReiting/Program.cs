﻿namespace MonetenReiting
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vavedete broya na uchastnitsite v anketata:");
            int totalParticipants = int.Parse(Console.ReadLine());

            double totalMarketValue = 0.0;
            int dogeUsers = 0, iotaUsers = 0, neoUsers = 0, estdUsers = 0;
            double dogeMarketValue = 0.0, iotaMarketValue = 0.0, neoMarketValue = 0.0, estdMarketValue = 0.0;

            double dogeRate = 0.07;
            double iotaRate = 1.44;
            double neoRate = 28.50;
            double estdRate = 25.0;

            for (int i = 0; i < totalParticipants; i++)
            {
                Console.WriteLine($"Valuta na uchastnik {i + 1}:");
                string currency = Console.ReadLine();
                Console.WriteLine($"Kolichestvo moneti na uchastnik {i + 1}:");
                double coins = double.Parse(Console.ReadLine());

                switch (currency.ToUpper())
                {
                    case "DOGE":
                        dogeUsers++;
                        dogeMarketValue += coins * dogeRate;
                        break;
                    case "IOTA":
                        iotaUsers++;
                        iotaMarketValue += coins * iotaRate;
                        break;
                    case "NEO":
                        neoUsers++;
                        neoMarketValue += coins * neoRate;
                        break;
                    case "ESTD":
                        estdUsers++;
                        estdMarketValue += coins * estdRate;
                        break;
                    default:
                        Console.WriteLine($"Valutata {currency} ne e poddurzhana.");
                        break;
                }
            }

            totalMarketValue = dogeMarketValue + iotaMarketValue + neoMarketValue + estdMarketValue;

            double dogePercentage = (dogeMarketValue / totalMarketValue) * 100;
            double iotaPercentage = (iotaMarketValue / totalMarketValue) * 100;
            double neoPercentage = (neoMarketValue / totalMarketValue) * 100;
            double estdPercentage = (estdMarketValue / totalMarketValue) * 100;

            Console.WriteLine($"Total votes = {totalParticipants}, Money in market = {totalMarketValue:F2} EUR");
            Console.WriteLine($"DOGE's contribution: {dogePercentage:F2}%; People who use DOGE: {dogeUsers}");
            Console.WriteLine($"IOTA's contribution: {iotaPercentage:F2}%; People who use IOTA: {iotaUsers}");
            Console.WriteLine($"NEO's contribution: {neoPercentage:F2}%; People who use NEO: {neoUsers}");
            Console.WriteLine($"ESTD's contribution: {estdPercentage:F2}%; People who use ESTD: {estdUsers}");
        }
    }
}