﻿namespace AlternativniMoneti
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Kolko bitcoin e kupil Stefcho?");
            double bitcoinAmount = double.Parse(Console.ReadLine());
            Console.WriteLine("Kakva e nachalnata cena za edin bitcoin?");
            double initialBitcoinPrice = double.Parse(Console.ReadLine());
            Console.WriteLine("Kakva e tekushtata cena za edin bitcoin?");
            double currentBitcoinPrice = double.Parse(Console.ReadLine());
            Console.WriteLine("Kolko ethereum iska da kupi Stefcho?");
            double ethereumQuantity = double.Parse(Console.ReadLine());
            Console.WriteLine("Kolko neo iska da kupi Stefcho?");
            double neoQuantity = double.Parse(Console.ReadLine());

            double profitFromBitcoin = bitcoinAmount * (currentBitcoinPrice - initialBitcoinPrice);
            double ethereumPrice = currentBitcoinPrice * 0.075;
            double totalEthereumCost = ethereumQuantity * ethereumPrice;
            double neoPrice = ethereumPrice * 0.40;
            double totalNeoCost = neoQuantity * neoPrice;
            double totalInvestmentNeeded = totalEthereumCost + totalNeoCost;

            if (profitFromBitcoin >= totalInvestmentNeeded)
            {
                double remainingProfit = profitFromBitcoin - totalInvestmentNeeded;
                Console.WriteLine($"Stefcho bought {ethereumQuantity:F4} Ethereum at a price of {ethereumPrice:F4}");
                Console.WriteLine($"Stefcho bought {neoQuantity:F4} Neo at a price of {neoPrice:F4}");
                Console.WriteLine($"Stefcho has {remainingProfit:F2} profits left to spend.");
            }
            else
            {
                double shortage = totalInvestmentNeeded - profitFromBitcoin;
                Console.WriteLine("Stefcho does not have enough money to make this investment.");
                Console.WriteLine($"He needs {shortage:F2} more in profits.");
            }
        }
    }
}